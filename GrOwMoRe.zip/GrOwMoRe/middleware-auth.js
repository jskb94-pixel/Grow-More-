const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Authentication middleware
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No token provided, access denied'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    
    // Check if user exists and is active
    const user = await User.findById(decoded.userId);
    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Token is not valid or user is inactive'
      });
    }

    // Add user info to request
    req.user = decoded;
    req.currentUser = user;
    next();

  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(401).json({
      success: false,
      message: 'Token is not valid'
    });
  }
};

// Role-based authorization middleware
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. Insufficient permissions'
      });
    }

    next();
  };
};

// Permission-based authorization
const requirePermission = (permission) => {
  return async (req, res, next) => {
    try {
      if (!req.currentUser) {
        return res.status(401).json({
          success: false,
          message: 'Not authenticated'
        });
      }

      const hasPermission = req.currentUser.hasPermission(permission);
      if (!hasPermission) {
        return res.status(403).json({
          success: false,
          message: `Access denied. Required permission: ${permission}`
        });
      }

      next();
    } catch (error) {
      console.error('Permission check error:', error);
      res.status(500).json({
        success: false,
        message: 'Server error'
      });
    }
  };
};

// Owner-only access (for jainabhishekmlk@gmail.com)
const ownerOnly = (req, res, next) => {
  if (!req.user || req.user.role !== 'owner') {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Owner privileges required'
    });
  }
  next();
};

// Business owner access (can access their own business data)
const businessOwnerOrAdmin = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated'
      });
    }

    // Owner and admin have full access
    if (['owner', 'admin'].includes(req.user.role)) {
      return next();
    }

    // Business owners can only access their own business
    if (req.user.role === 'business') {
      const user = await User.findById(req.user.userId);
      
      // Check if they're accessing their own business
      const businessId = req.params.businessId || req.params.id;
      if (user.businessId && user.businessId.toString() === businessId) {
        return next();
      }
    }

    res.status(403).json({
      success: false,
      message: 'Access denied. Can only access your own business'
    });

  } catch (error) {
    console.error('Business access check error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// Admin or owner access
const adminOrOwner = (req, res, next) => {
  if (!req.user || !['admin', 'owner'].includes(req.user.role)) {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Admin or owner privileges required'
    });
  }
  next();
};

// Optional auth - continues even if no token
const optionalAuth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
      const user = await User.findById(decoded.userId);
      
      if (user && user.isActive) {
        req.user = decoded;
        req.currentUser = user;
      }
    }
    
    next();
  } catch (error) {
    // Continue without authentication if token is invalid
    next();
  }
};

// Rate limiting middleware for sensitive operations
const sensitiveOperation = (req, res, next) => {
  // Add additional rate limiting for password changes, etc.
  next();
};

module.exports = {
  auth,
  authorize,
  requirePermission,
  ownerOnly,
  businessOwnerOrAdmin,
  adminOrOwner,
  optionalAuth,
  sensitiveOperation
};