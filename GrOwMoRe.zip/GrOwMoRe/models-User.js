const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  role: {
    type: String,
    enum: ['owner', 'admin', 'business', 'consumer'],
    default: 'consumer'
  },
  avatar: {
    type: String,
    default: ''
  },
  phone: {
    type: String,
    default: ''
  },
  location: {
    type: String,
    default: ''
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  lastLogin: {
    type: Date,
    default: null
  },
  // Consumer specific fields
  following: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Business'
  }],
  favorites: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Business'
  }],
  notifications: [{
    type: {
      type: String,
      enum: ['offer', 'business_update', 'follow', 'review_response'],
      required: true
    },
    title: String,
    message: String,
    businessId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Business'
    },
    isRead: {
      type: Boolean,
      default: false
    },
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Business owner specific fields
  businessId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Business'
  }
}, {
  timestamps: true
});

// Special owner setup
userSchema.pre('save', async function(next) {
  // Set owner role for specific email
  if (this.email === 'jainabhishekmlk@gmail.com') {
    this.role = 'owner';
  }
  
  // Hash password if modified
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Update last login
userSchema.methods.updateLastLogin = function() {
  this.lastLogin = new Date();
  return this.save();
};

// Get user permissions based on role
userSchema.methods.getPermissions = function() {
  const permissions = {
    owner: ['*'], // All permissions
    admin: ['manage_businesses', 'manage_users', 'manage_campaigns', 'view_analytics'],
    business: ['manage_own_business', 'view_own_analytics', 'manage_offers'],
    consumer: ['view_businesses', 'follow_businesses', 'write_reviews']
  };
  
  return permissions[this.role] || permissions.consumer;
};

// Check if user has specific permission
userSchema.methods.hasPermission = function(permission) {
  const userPermissions = this.getPermissions();
  return userPermissions.includes('*') || userPermissions.includes(permission);
};

module.exports = mongoose.model('User', userSchema);