const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Business = require('../models/Business');
const Review = require('../models/Review');

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/growmore');
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Business.deleteMany({});
    await Review.deleteMany({});
    console.log('Cleared existing data');

    // Create Owner (CEO) - jainabhishekmlk@gmail.com
    const ownerPassword = await bcrypt.hash('owner123456', 12);
    const owner = new User({
      name: 'Jainabhishek',
      email: 'jainabhishekmlk@gmail.com',
      password: ownerPassword,
      role: 'owner',
      phone: '+91-9876543210',
      location: 'India',
      isActive: true,
      isEmailVerified: true
    });
    await owner.save();
    console.log('âœ“ Owner account created');

    // Create Admin user
    const adminPassword = await bcrypt.hash('admin123456', 12);
    const admin = new User({
      name: 'Admin User',
      email: 'admin@growmore.com',
      password: adminPassword,
      role: 'admin',
      phone: '+91-9876543211',
      location: 'Mumbai, India',
      isActive: true,
      isEmailVerified: true
    });
    await admin.save();
    console.log('âœ“ Admin account created');

    // Create Business Owner users
    const businessOwnerPassword = await bcrypt.hash('business123', 12);
    
    const businessOwner1 = new User({
      name: 'Rahul Sharma',
      email: 'rahul@artisancoffee.com',
      password: businessOwnerPassword,
      role: 'business',
      phone: '+91-9876543212',
      location: 'Delhi, India',
      isActive: true,
      isEmailVerified: true
    });
    await businessOwner1.save();

    const businessOwner2 = new User({
      name: 'Priya Patel',
      email: 'priya@freshbites.com',
      password: businessOwnerPassword,
      role: 'business',
      phone: '+91-9876543213',
      location: 'Mumbai, India',
      isActive: true,
      isEmailVerified: true
    });
    await businessOwner2.save();

    const businessOwner3 = new User({
      name: 'Amit Singh',
      email: 'amit@techrepair.com',
      password: businessOwnerPassword,
      role: 'business',
      phone: '+91-9876543214',
      location: 'Bangalore, India',
      isActive: true,
      isEmailVerified: true
    });
    await businessOwner3.save();
    console.log('âœ“ Business owner accounts created');

    // Create Consumer users
    const consumerPassword = await bcrypt.hash('consumer123', 12);
    
    const consumer1 = new User({
      name: 'John Smith',
      email: 'john@consumer.com',
      password: consumerPassword,
      role: 'consumer',
      phone: '+91-9876543215',
      location: 'Delhi, India',
      isActive: true,
      isEmailVerified: true
    });
    await consumer1.save();

    const consumer2 = new User({
      name: 'Sarah Johnson',
      email: 'sarah@consumer.com',
      password: consumerPassword,
      role: 'consumer',
      phone: '+91-9876543216',
      location: 'Mumbai, India',
      isActive: true,
      isEmailVerified: true
    });
    await consumer2.save();
    console.log('âœ“ Consumer accounts created');

    // Create Businesses
    const business1 = new Business({
      name: 'Artisan Coffee Co.',
      description: 'Premium coffee shop serving handcrafted artisan coffee blends with a cozy atmosphere perfect for work and relaxation.',
      category: 'Cafe',
      subcategory: 'Coffee Shop',
      owner: businessOwner1._id,
      email: 'contact@artisancoffee.com',
      phone: '+91-11-12345678',
      website: 'https://artisancoffee.com',
      address: {
        street: '123 Coffee Street',
        city: 'New Delhi',
        state: 'Delhi',
        zipCode: '110001',
        country: 'India',
        coordinates: {
          lat: 28.6139,
          lng: 77.2090
        }
      },
      workingHours: [
        { day: 'monday', open: '07:00', close: '22:00' },
        { day: 'tuesday', open: '07:00', close: '22:00' },
        { day: 'wednesday', open: '07:00', close: '22:00' },
        { day: 'thursday', open: '07:00', close: '22:00' },
        { day: 'friday', open: '07:00', close: '23:00' },
        { day: 'saturday', open: '08:00', close: '23:00' },
        { day: 'sunday', open: '08:00', close: '21:00' }
      ],
      isActive: true,
      isVerified: true,
      isFeatured: true,
      verificationDate: new Date(),
      analytics: {
        profileViews: 1240,
        totalOfferClicks: 89,
        engagement: 0.72,
        monthlyViews: [
          { month: '8', year: 2025, views: 1240 },
          { month: '7', year: 2025, views: 1100 },
          { month: '6', year: 2025, views: 950 }
        ]
      },
      rating: {
        average: 4.8,
        total: 25,
        breakdown: {
          5: 20,
          4: 4,
          3: 1,
          2: 0,
          1: 0
        }
      },
      referral: {
        code: 'ARTISAN10',
        reward: '10% off next purchase',
        uses: 15,
        isActive: true
      },
      rank: {
        category: 1,
        overall: 5
      },
      tags: ['coffee', 'artisan', 'cozy', 'wifi', 'laptop-friendly'],
      features: ['wifi', 'outdoor_seating', 'online_ordering']
    });

    // Link business to owner
    businessOwner1.businessId = business1._id;
    await businessOwner1.save();

    const business2 = new Business({
      name: 'Fresh Bites Bakery',
      description: 'Artisanal bakery offering fresh breads, pastries, and custom cakes made with premium ingredients daily.',
      category: 'Restaurant',
      subcategory: 'Bakery',
      owner: businessOwner2._id,
      email: 'orders@freshbites.com',
      phone: '+91-22-87654321',
      website: 'https://freshbites.com',
      address: {
        street: '456 Baker Lane',
        city: 'Mumbai',
        state: 'Maharashtra',
        zipCode: '400001',
        country: 'India',
        coordinates: {
          lat: 19.0760,
          lng: 72.8777
        }
      },
      workingHours: [
        { day: 'monday', open: '06:00', close: '20:00' },
        { day: 'tuesday', open: '06:00', close: '20:00' },
        { day: 'wednesday', open: '06:00', close: '20:00' },
        { day: 'thursday', open: '06:00', close: '20:00' },
        { day: 'friday', open: '06:00', close: '21:00' },
        { day: 'saturday', open: '06:00', close: '21:00' },
        { day: 'sunday', open: '07:00', close: '19:00' }
      ],
      isActive: true,
      isVerified: false,
      isFeatured: false,
      analytics: {
        profileViews: 856,
        totalOfferClicks: 67,
        engagement: 0.65,
        monthlyViews: [
          { month: '8', year: 2025, views: 856 },
          { month: '7', year: 2025, views: 720 },
          { month: '6', year: 2025, views: 650 }
        ]
      },
      rating: {
        average: 4.6,
        total: 18,
        breakdown: {
          5: 12,
          4: 5,
          3: 1,
          2: 0,
          1: 0
        }
      },
      referral: {
        code: 'FRESHBITES20',
        reward: 'Free dessert with meal',
        uses: 8,
        isActive: true
      },
      rank: {
        category: 2,
        overall: 12
      },
      tags: ['bakery', 'fresh', 'custom-cakes', 'artisan', 'daily-baked'],
      features: ['delivery', 'pickup', 'online_ordering']
    });

    businessOwner2.businessId = business2._id;
    await businessOwner2.save();

    const business3 = new Business({
      name: 'Tech Repair Hub',
      description: 'Professional electronics repair service for smartphones, laptops, and gadgets with certified technicians.',
      category: 'Services',
      subcategory: 'Electronics Repair',
      owner: businessOwner3._id,
      email: 'support@techrepair.com',
      phone: '+91-80-98765432',
      website: 'https://techrepairhub.com',
      address: {
        street: '789 Tech Park',
        city: 'Bangalore',
        state: 'Karnataka',
        zipCode: '560001',
        country: 'India',
        coordinates: {
          lat: 12.9716,
          lng: 77.5946
        }
      },
      workingHours: [
        { day: 'monday', open: '09:00', close: '19:00' },
        { day: 'tuesday', open: '09:00', close: '19:00' },
        { day: 'wednesday', open: '09:00', close: '19:00' },
        { day: 'thursday', open: '09:00', close: '19:00' },
        { day: 'friday', open: '09:00', close: '19:00' },
        { day: 'saturday', open: '10:00', close: '17:00' },
        { day: 'sunday', isClosed: true }
      ],
      isActive: true,
      isVerified: true,
      isFeatured: false,
      verificationDate: new Date(),
      analytics: {
        profileViews: 654,
        totalOfferClicks: 43,
        engagement: 0.58,
        monthlyViews: [
          { month: '8', year: 2025, views: 654 },
          { month: '7', year: 2025, views: 580 },
          { month: '6', year: 2025, views: 520 }
        ]
      },
      rating: {
        average: 4.4,
        total: 12,
        breakdown: {
          5: 6,
          4: 5,
          3: 1,
          2: 0,
          1: 0
        }
      },
      referral: {
        code: 'TECHFIX15',
        reward: '15% off repairs',
        uses: 5,
        isActive: true
      },
      rank: {
        category: 1,
        overall: 8
      },
      tags: ['electronics', 'repair', 'smartphones', 'laptops', 'certified'],
      features: ['pickup', 'wifi', 'parking']
    });

    businessOwner3.businessId = business3._id;
    await businessOwner3.save();

    await business1.save();
    await business2.save();
    await business3.save();
    console.log('âœ“ Businesses created');

    // Add followers and partnerships
    consumer1.following.push(business1._id, business2._id);
    consumer1.favorites.push(business1._id, business3._id);
    consumer2.following.push(business1._id, business3._id);
    consumer2.favorites.push(business1._id, business2._id, business3._id);

    await consumer1.save();
    await consumer2.save();

    // Add followers to businesses
    business1.followers.push(
      { user: consumer1._id },
      { user: consumer2._id }
    );
    business2.followers.push(
      { user: consumer1._id }
    );
    business3.followers.push(
      { user: consumer2._id }
    );

    // Add partnerships
    business1.partnerships.push({
      partner: business2._id,
      type: 'cross-promotion',
      status: 'active',
      description: 'Coffee + pastry combo deals'
    });
    business2.partnerships.push({
      partner: business1._id,
      type: 'cross-promotion',
      status: 'active',
      description: 'Coffee + pastry combo deals'
    });

    await business1.save();
    await business2.save();
    await business3.save();
    console.log('âœ“ User relationships and partnerships created');

    console.log('\nðŸŽ‰ Database seeded successfully!');
    console.log('\nðŸ‘¤ Login Credentials:');
    console.log('Owner/CEO: jainabhishekmlk@gmail.com / owner123456');
    console.log('Admin: admin@growmore.com / admin123456');
    console.log('Business: rahul@artisancoffee.com / business123');
    console.log('Consumer: john@consumer.com / consumer123');

    process.exit(0);

  } catch (error) {
    console.error('âŒ Error seeding database:', error);
    process.exit(1);
  }
};

// Run the seed function
seedData();