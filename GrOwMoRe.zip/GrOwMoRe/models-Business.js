const mongoose = require('mongoose');

const businessSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100
  },
  description: {
    type: String,
    required: true,
    maxlength: 1000
  },
  category: {
    type: String,
    required: true,
    enum: ['Restaurant', 'Cafe', 'Retail', 'Services', 'Technology', 'Health', 'Beauty', 'Education', 'Entertainment', 'Other']
  },
  subcategory: {
    type: String,
    default: ''
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  email: {
    type: String,
    required: true,
    lowercase: true
  },
  phone: {
    type: String,
    required: true
  },
  website: {
    type: String,
    default: ''
  },
  address: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String,
    coordinates: {
      lat: Number,
      lng: Number
    }
  },
  images: [{
    url: String,
    caption: String,
    isPrimary: {
      type: Boolean,
      default: false
    }
  }],
  logo: {
    type: String,
    default: ''
  },
  coverImage: {
    type: String,
    default: ''
  },
  workingHours: [{
    day: {
      type: String,
      enum: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    },
    open: String,
    close: String,
    isClosed: {
      type: Boolean,
      default: false
    }
  }],
  // Business Status
  isActive: {
    type: Boolean,
    default: true
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  verificationDate: Date,
  // Analytics & Engagement
  analytics: {
    profileViews: {
      type: Number,
      default: 0
    },
    totalOfferClicks: {
      type: Number,
      default: 0
    },
    monthlyViews: [{
      month: String,
      year: Number,
      views: Number
    }],
    engagement: {
      type: Number,
      default: 0,
      min: 0,
      max: 1
    }
  },
  followers: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    followedAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Rating & Reviews
  rating: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    total: {
      type: Number,
      default: 0
    },
    breakdown: {
      5: { type: Number, default: 0 },
      4: { type: Number, default: 0 },
      3: { type: Number, default: 0 },
      2: { type: Number, default: 0 },
      1: { type: Number, default: 0 }
    }
  },
  // Referral System
  referral: {
    code: {
      type: String,
      unique: true,
      sparse: true
    },
    reward: {
      type: String,
      default: ''
    },
    uses: {
      type: Number,
      default: 0
    },
    isActive: {
      type: Boolean,
      default: false
    }
  },
  // Partnership & Networking
  partnerships: [{
    partner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Business'
    },
    type: {
      type: String,
      enum: ['cross-promotion', 'collaboration', 'supplier', 'customer']
    },
    status: {
      type: String,
      enum: ['pending', 'active', 'inactive'],
      default: 'pending'
    },
    description: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Ranking
  rank: {
    category: {
      type: Number,
      default: 0
    },
    overall: {
      type: Number,
      default: 0
    },
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  // Social Media
  socialMedia: {
    facebook: String,
    instagram: String,
    twitter: String,
    linkedin: String
  },
  // Tags for better searchability
  tags: [String],
  // Special Business Features
  features: [{
    type: String,
    enum: ['delivery', 'pickup', 'online_ordering', 'reservations', 'parking', 'wifi', 'outdoor_seating']
  }]
}, {
  timestamps: true
});

// Generate referral code
businessSchema.methods.generateReferralCode = function() {
  const code = this.name.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 6) + Math.floor(Math.random() * 100);
  this.referral.code = code;
  this.referral.isActive = true;
  return code;
};

// Update analytics
businessSchema.methods.incrementViews = function() {
  this.analytics.profileViews += 1;
  
  // Update monthly views
  const now = new Date();
  const monthYear = `${now.getMonth() + 1}-${now.getFullYear()}`;
  
  const existingMonth = this.analytics.monthlyViews.find(m => 
    m.month === monthYear.split('-')[0] && m.year === parseInt(monthYear.split('-')[1])
  );
  
  if (existingMonth) {
    existingMonth.views += 1;
  } else {
    this.analytics.monthlyViews.push({
      month: monthYear.split('-')[0],
      year: parseInt(monthYear.split('-')[1]),
      views: 1
    });
  }
  
  return this.save();
};

// Update rating
businessSchema.methods.updateRating = function(newRating) {
  const ratings = this.rating.breakdown;
  ratings[newRating] += 1;
  this.rating.total += 1;
  
  const totalRating = (ratings[5] * 5) + (ratings[4] * 4) + (ratings[3] * 3) + (ratings[2] * 2) + (ratings[1] * 1);
  this.rating.average = totalRating / this.rating.total;
  
  return this.save();
};

// Follow/Unfollow business
businessSchema.methods.toggleFollow = function(userId) {
  const existingFollower = this.followers.find(f => f.user.toString() === userId.toString());
  
  if (existingFollower) {
    this.followers = this.followers.filter(f => f.user.toString() !== userId.toString());
    return { action: 'unfollowed', count: this.followers.length };
  } else {
    this.followers.push({ user: userId });
    return { action: 'followed', count: this.followers.length };
  }
};

// Text search index
businessSchema.index({
  name: 'text',
  description: 'text',
  tags: 'text'
});

// Location index for geospatial queries
businessSchema.index({ 'address.coordinates': '2dsphere' });

module.exports = mongoose.model('Business', businessSchema);