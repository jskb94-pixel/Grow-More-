#!/bin/bash

# Grow More Platform Setup Script
# This script sets up the complete full-stack application

echo "ðŸš€ Welcome to Grow More Platform Setup!"
echo "This script will set up the complete full-stack application."
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}âœ“${NC} $1"
}

print_error() {
    echo -e "${RED}âœ—${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}âš ${NC} $1"
}

print_info() {
    echo -e "${BLUE}â„¹${NC} $1"
}

# Check if Node.js is installed
check_nodejs() {
    if command -v node > /dev/null 2>&1; then
        NODE_VERSION=$(node --version)
        print_status "Node.js is installed: $NODE_VERSION"
        return 0
    else
        print_error "Node.js is not installed!"
        echo "Please install Node.js from: https://nodejs.org/"
        exit 1
    fi
}

# Check if MongoDB is installed
check_mongodb() {
    if command -v mongod > /dev/null 2>&1; then
        print_status "MongoDB is installed"
        return 0
    else
        print_warning "MongoDB not found locally."
        print_info "You can use MongoDB Atlas (cloud) instead."
        print_info "Get connection string from: https://cloud.mongodb.com/"
        return 1
    fi
}

# Create project directory structure
setup_directories() {
    print_info "Setting up directory structure..."
    
    mkdir -p grow-more-platform
    cd grow-more-platform
    
    mkdir -p backend/{models,routes,middleware,controllers,utils,scripts,uploads}
    mkdir -p frontend/src/{components/{Auth,Dashboard,Business,UI,Layout},services,hooks,utils,styles}
    mkdir -p frontend/public
    
    print_status "Directory structure created"
}

# Setup backend
setup_backend() {
    print_info "Setting up backend..."
    cd backend
    
    # Create package.json if not exists
    if [ ! -f "package.json" ]; then
        npm init -y
        npm install express mongoose bcryptjs jsonwebtoken cors dotenv multer nodemailer express-rate-limit helmet express-validator socket.io
        npm install --save-dev nodemon
    fi
    
    # Create .env file
    if [ ! -f ".env" ]; then
        cat > .env << EOL
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/growmore
JWT_SECRET=your-super-secret-jwt-key-$(openssl rand -base64 32)
FRONTEND_URL=http://localhost:3000
OWNER_EMAIL=jainabhishekmlk@gmail.com

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password

# File Upload Configuration
MAX_FILE_SIZE=10485760
UPLOAD_PATH=./uploads
EOL
        print_status "Backend environment file created"
    fi
    
    cd ..
    print_status "Backend setup complete"
}

# Setup frontend
setup_frontend() {
    print_info "Setting up frontend..."
    cd frontend
    
    # Create React app if not exists
    if [ ! -f "package.json" ]; then
        npx create-react-app . --template typescript || npx create-react-app .
        npm install react-router-dom axios styled-components react-toastify react-hook-form react-query framer-motion lucide-react chart.js react-chartjs-2
    fi
    
    cd ..
    print_status "Frontend setup complete"
}

# Start MongoDB if local
start_mongodb() {
    if command -v mongod > /dev/null 2>&1; then
        print_info "Starting MongoDB..."
        
        # Check if MongoDB is already running
        if pgrep -x "mongod" > /dev/null; then
            print_status "MongoDB is already running"
        else
            # Start MongoDB in background
            mongod --dbpath ./data/db --fork --logpath ./mongodb.log 2>/dev/null || {
                print_warning "Could not start MongoDB with custom path"
                print_info "Trying to start MongoDB with default settings..."
                mongod --fork --logpath ./mongodb.log 2>/dev/null || {
                    print_warning "Could not start MongoDB automatically"
                    print_info "Please start MongoDB manually: mongod"
                }
            }
        fi
    fi
}

# Seed database
seed_database() {
    print_info "Seeding database with initial data..."
    cd backend
    
    if [ -f "scripts/seed.js" ]; then
        node scripts/seed.js
        print_status "Database seeded successfully"
    else
        print_warning "Seed script not found, skipping database seeding"
    fi
    
    cd ..
}

# Create startup scripts
create_startup_scripts() {
    print_info "Creating startup scripts..."
    
    # Backend start script
    cat > start-backend.sh << EOL
#!/bin/bash
echo "Starting Grow More Backend..."
cd backend
npm run dev
EOL
    chmod +x start-backend.sh
    
    # Frontend start script
    cat > start-frontend.sh << EOL
#!/bin/bash
echo "Starting Grow More Frontend..."
cd frontend
npm start
EOL
    chmod +x start-frontend.sh
    
    # Combined start script
    cat > start-app.sh << EOL
#!/bin/bash
echo "Starting Complete Grow More Application..."

# Start backend in background
./start-backend.sh &
BACKEND_PID=\$!

# Wait a bit for backend to start
sleep 5

# Start frontend
./start-frontend.sh &
FRONTEND_PID=\$!

echo "Backend PID: \$BACKEND_PID"
echo "Frontend PID: \$FRONTEND_PID"
echo ""
echo "ðŸŽ‰ Application started!"
echo "Backend: http://localhost:5000"
echo "Frontend: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for user interrupt
trap 'kill \$BACKEND_PID \$FRONTEND_PID' INT
wait
EOL
    chmod +x start-app.sh
    
    print_status "Startup scripts created"
}

# Main setup function
main() {
    echo ""
    print_info "Starting setup process..."
    echo ""
    
    # Check prerequisites
    check_nodejs
    check_mongodb
    
    # Setup project
    setup_directories
    setup_backend
    setup_frontend
    
    # Database setup
    start_mongodb
    sleep 3  # Wait for MongoDB to start
    seed_database
    
    # Create convenience scripts
    create_startup_scripts
    
    echo ""
    echo "ðŸŽ‰ Setup complete!"
    echo ""
    print_status "Project structure created in: grow-more-platform/"
    print_status "Backend configured with MongoDB and JWT"
    print_status "Frontend configured with React and all dependencies"
    print_status "Database seeded with sample data"
    echo ""
    echo "ðŸ“‹ Login Credentials:"
    echo "Owner/CEO: jainabhishekmlk@gmail.com / owner123456"
    echo "Admin: admin@growmore.com / admin123456"
    echo "Business: rahul@artisancoffee.com / business123"
    echo "Consumer: john@consumer.com / consumer123"
    echo ""
    echo "ðŸš€ To start the application:"
    echo "1. Run: cd grow-more-platform"
    echo "2. Run: ./start-app.sh (starts both backend and frontend)"
    echo ""
    echo "Or start individually:"
    echo "Backend: ./start-backend.sh"
    echo "Frontend: ./start-frontend.sh"
    echo ""
    print_info "Backend will be available at: http://localhost:5000"
    print_info "Frontend will be available at: http://localhost:3000"
    echo ""
    echo "ðŸ“– Check README.md for detailed documentation"
    echo ""
}

# Run main function
main "$@"