# Grow More - Business Growth Platform

A comprehensive full-stack business growth and customer engagement platform built with Node.js, Express, MongoDB, and React.

## ðŸš€ Features

### For Business Owners
- **Analytics Dashboard**: Profile views, offer clicks, customer engagement metrics
- **Customer Follow System**: Build and manage follower base with notifications
- **Referral System**: Generate referral codes and track performance
- **Business Ranking**: Category-based ranking system
- **Verification Badge**: Build trust with verified status
- **Networking Hub**: Connect and partner with other businesses

### For Consumers
- **Business Discovery**: Search and browse businesses by category/location
- **Favorites & Follows**: Save and follow preferred businesses
- **Smart Notifications**: Get alerts for new offers from followed businesses
- **Reviews & Ratings**: Rate and review businesses
- **Exclusive Offers**: Access platform-exclusive discounts

### For Administrators
- **Full Control Panel**: Manage businesses, users, and platform content
- **Featured Business Promotion**: Highlight businesses for increased visibility
- **Seasonal Campaigns**: Create themed promotional campaigns
- **Analytics**: Platform-wide insights and metrics

### For Owner/CEO (jainabhishekmlk@gmail.com)
- **Super Admin Access**: Complete platform control and oversight
- **Strategic Management**: High-level platform decisions and configurations
- **Full Analytics**: Comprehensive platform performance metrics

## ðŸ›  Tech Stack

### Backend
- **Node.js** & **Express.js** - Server framework
- **MongoDB** with **Mongoose** - Database and ODM
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **multer** - File uploads
- **nodemailer** - Email notifications
- **socket.io** - Real-time notifications

### Frontend
- **React 18** - UI library
- **React Router** - Navigation
- **styled-components** - Styling
- **React Query** - Data fetching
- **Chart.js** - Analytics charts
- **Framer Motion** - Animations
- **React Hook Form** - Form handling

## ðŸ“‹ Prerequisites

- Node.js (v16 or higher)
- MongoDB (v5 or higher)
- npm or yarn
- Git

## âš¡ Quick Start

### 1. Clone the Repository
```bash
git clone <repository-url>
cd grow-more-platform
```

### 2. Backend Setup
```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env file with your configurations
nano .env

# Start MongoDB (if running locally)
mongod

# Run database seeds (optional)
npm run seed

# Start backend server
npm run dev
```

The backend will be running on `http://localhost:5000`

### 3. Frontend Setup
```bash
# Navigate to frontend directory (in new terminal)
cd frontend

# Install dependencies
npm install

# Start frontend development server
npm start
```

The frontend will be running on `http://localhost:3000`

## ðŸ”§ Environment Configuration

### Backend (.env)
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/growmore
JWT_SECRET=your-super-secret-jwt-key
FRONTEND_URL=http://localhost:3000
OWNER_EMAIL=jainabhishekmlk@gmail.com

# Email configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
```

### Frontend
The frontend uses a proxy to connect to the backend. No additional environment setup needed for development.

## ðŸ—‚ Project Structure

```
grow-more-platform/
â”œâ”€â”€ backend/
â”‚   â”œâ”€â”€ models/
â”‚   â”‚   â”œâ”€â”€ User.js
â”‚   â”‚   â”œâ”€â”€ Business.js
â”‚   â”‚   â”œâ”€â”€ Offer.js
â”‚   â”‚   â”œâ”€â”€ Review.js
â”‚   â”‚   â””â”€â”€ Campaign.js
â”‚   â”œâ”€â”€ routes/
â”‚   â”‚   â”œâ”€â”€ auth.js
â”‚   â”‚   â”œâ”€â”€ users.js
â”‚   â”‚   â”œâ”€â”€ businesses.js
â”‚   â”‚   â”œâ”€â”€ offers.js
â”‚   â”‚   â”œâ”€â”€ reviews.js
â”‚   â”‚   â”œâ”€â”€ analytics.js
â”‚   â”‚   â””â”€â”€ campaigns.js
â”‚   â”œâ”€â”€ middleware/
â”‚   â”‚   â”œâ”€â”€ auth.js
â”‚   â”‚   â”œâ”€â”€ upload.js
â”‚   â”‚   â””â”€â”€ validation.js
â”‚   â”œâ”€â”€ controllers/
â”‚   â”œâ”€â”€ utils/
â”‚   â”œâ”€â”€ uploads/
â”‚   â”œâ”€â”€ scripts/
â”‚   â”‚   â””â”€â”€ seed.js
â”‚   â”œâ”€â”€ server.js
â”‚   â”œâ”€â”€ package.json
â”‚   â””â”€â”€ .env.example
â””â”€â”€ frontend/
    â”œâ”€â”€ src/
    â”‚   â”œâ”€â”€ components/
    â”‚   â”‚   â”œâ”€â”€ Auth/
    â”‚   â”‚   â”œâ”€â”€ Dashboard/
    â”‚   â”‚   â”œâ”€â”€ Business/
    â”‚   â”‚   â”œâ”€â”€ UI/
    â”‚   â”‚   â””â”€â”€ Layout/
    â”‚   â”œâ”€â”€ services/
    â”‚   â”œâ”€â”€ hooks/
    â”‚   â”œâ”€â”€ utils/
    â”‚   â”œâ”€â”€ styles/
    â”‚   â”œâ”€â”€ App.js
    â”‚   â””â”€â”€ index.js
    â”œâ”€â”€ public/
    â”œâ”€â”€ package.json
    â””â”€â”€ README.md
```

## ðŸ” Authentication & Authorization

### User Roles
- **Owner** (`jainabhishekmlk@gmail.com`) - Full platform control
- **Admin** - Business and user management
- **Business** - Own business management
- **Consumer** - Browse and interact with businesses

### Special Owner Setup
The email `jainabhishekmlk@gmail.com` is automatically assigned the "owner" role with super admin privileges.

## ðŸ“Š API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update profile

### Businesses
- `GET /api/businesses` - Get all businesses
- `POST /api/businesses` - Create business
- `GET /api/businesses/:id` - Get business details
- `PUT /api/businesses/:id` - Update business
- `DELETE /api/businesses/:id` - Delete business

### Analytics
- `GET /api/analytics/business/:id` - Business analytics
- `GET /api/analytics/platform` - Platform analytics (admin only)

## ðŸš€ Deployment

### Backend Deployment (Heroku/Railway/DigitalOcean)
1. Set environment variables
2. Connect MongoDB Atlas
3. Deploy with `npm start`

### Frontend Deployment (Netlify/Vercel)
1. Build with `npm run build`
2. Deploy build folder
3. Set backend API URL

### Docker Deployment
```bash
# Build and run with Docker Compose
docker-compose up --build
```

## ðŸ§ª Testing

### Backend Tests
```bash
cd backend
npm test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## ðŸ“± Mobile App Conversion

To convert to mobile app:

1. **Using Capacitor/Cordova**:
   ```bash
   npm install @capacitor/core @capacitor/cli
   npx cap init
   npx cap add ios
   npx cap add android
   ```

2. **Using React Native**:
   - Port components to React Native
   - Use same backend APIs

3. **Using Web-to-App Services**:
   - Upload to AppMySite, Natively, or WebIntoApp
   - Generate APK/iOS files

## ðŸ¤ Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## ðŸ“„ License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.

## ðŸ‘¨â€ðŸ’» Owner

**Jainabhishek** (jainabhishekmlk@gmail.com)
- Platform Owner & CEO
- Full administrative access
- Strategic platform decisions

## ðŸ†˜ Support

For support and queries:
- Email: support@growmore.com
- GitHub Issues: [Create Issue](https://github.com/your-repo/issues)

## ðŸ“ˆ Roadmap

- [ ] Mobile app development
- [ ] Advanced analytics dashboard
- [ ] Payment integration
- [ ] Multi-language support
- [ ] AI-powered business recommendations
- [ ] Advanced notification system
- [ ] Social media integration
- [ ] Advanced search and filtering

---

**Built with â¤ï¸ for business growth and customer engagement**